﻿namespace AngelClothing.Models
{
    public class ProductData
    {

        public static List<ProductModel> GetProducts()
        {
            List<ProductModel> products = new List<ProductModel>
            {
                new ProductModel {
                    ProductId = 1,
                    ProductName = "MGN T-shirt",
                    ProductDescription = "Tops",
                    ProductImage = "MGN T-Shirt.PNG",
                    ProductPrice = 30
                },
                new ProductModel {
                    ProductId = 2,
                    ProductName = "MGN Jeans",
                    ProductDescription = "Bottoms",
                    ProductImage = "MGN Jeans.jpg",
                    ProductPrice = 60
                },
                new ProductModel {
                    ProductId = 3,
                    ProductName = "MGN Hoodie",
                    ProductDescription = "Tops",
                    ProductImage = "MGN Hoodie.PNG",
                    ProductPrice = 50
                },
                new ProductModel {
                    ProductId = 4,
                    ProductName = "MGN Beanie",
                    ProductDescription = "Headwear",
                    ProductImage = "MGN Beanie.PNG",
                    ProductPrice = 15
                },
                new ProductModel {
                    ProductId = 5,
                    ProductName = "MGN Sweats",
                    ProductDescription = "Bottoms",
                    ProductImage = "MGN Sweatpants.PNG",
                    ProductPrice = 40
                },
                new ProductModel {
                    ProductId = 6,
                    ProductName = "MGN Long-sleeve",
                    ProductDescription = "Tops",
                    ProductImage = "MGN Long-Sleeve.PNG",
                    ProductPrice = 35
                }
            };
            return products;
        }

        public static ProductModel GetProduct(int id)
        {
            List<ProductModel> products = ProductData.GetProducts();
            foreach (ProductModel product in products)
            {
                if (product.ProductId == id)
                {
                    return product;
                }
            }
            return new ProductModel();
        }
    }
}
