﻿using AngelClothing.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace AngelClothing.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()

        {

            return View();

        }
        public IActionResult Contact()

        {

            return View();

        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult FAQ()
        {
            return View();
        }
        [HttpGet]
        public IActionResult Tools()
        {
            HttpContext.Session.SetString("FirstName", "YourFirstName");
            HttpContext.Session.SetString("LastName", "YourLastName");
            HttpContext.Session.SetString("Course", "IT2030");
            HttpContext.Session.SetString("FavNum", "YourFavoriteNumber");
            //convert string to integers?

            return View(new MySession());
        }

        [HttpPost]
        public IActionResult Tools(MySession session)
        {
            // Set session variables from form submission
            HttpContext.Session.SetString("FirstName", session.FirstName);
            HttpContext.Session.SetString("LastName", session.LastName);
            HttpContext.Session.SetString("Course", session.Course);
            HttpContext.Session.SetString("FavNum", session.FavNum);

            return RedirectToAction(nameof(Tools));
        }

        [HttpPost]
        public IActionResult ClearSession()
        {
            // Clear session variables
            HttpContext.Session.Clear();

            return RedirectToAction(nameof(Tools));
        }

        [HttpGet]
        public IActionResult DisplaySession()
        {
            // Get session variables
            string? firstName = HttpContext.Session.GetString("FirstName");
            string? lastName = HttpContext.Session.GetString("LastName");
            string? course = HttpContext.Session.GetString("Course");
            string? favNum = HttpContext.Session.GetString("FavNum");

            MySession session = new MySession
            {
                FirstName = "Angel",
                LastName = "Martinez",
                Course = "IT2030",
                FavNum = 6 
            };

            return View(session);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


    }
}


