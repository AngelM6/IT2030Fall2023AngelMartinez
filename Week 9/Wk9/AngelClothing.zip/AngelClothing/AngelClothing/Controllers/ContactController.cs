﻿using AngelClothing.Models;
using Microsoft.AspNetCore.Mvc;
using System.Reflection;

namespace AngelClothing.Controllers
{
    public class ContactController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

         [HttpPost]
        public IActionResult Index(ContactModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

        

            return RedirectToAction("Index");
        }
    }

}
