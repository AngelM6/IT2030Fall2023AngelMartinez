using System.ComponentModel.DataAnnotations;

namespace TipCalculator.Models
{
    public class Calculator
    {
        [Required(ErrorMessage = "Please enter a value for cost of meal.")]
        [Range(0.01, 10000000.0, ErrorMessage = "Cost of meal must be greater than zero.")]/*changed range value from 0.00 to 0.01 so user cant input 0*/
        public double? MealCost { get; set; }

        public double? CalculateTip(double percent) 
        {
            if (MealCost.HasValue)
            {
                var tip = MealCost.Value * percent; /*Error calculation, changed / to * to recieve correct calculation*/
                return tip;
            }
            else
            {
                return 0;
            }
        }
    }
}