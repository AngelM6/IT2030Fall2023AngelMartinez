﻿using Microsoft.AspNetCore.Mvc;

namespace AngelClothing.Models
{
    public class MySession
    { 
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Course { get; set; }
        public int  FavNum { get; set; }
    }

}